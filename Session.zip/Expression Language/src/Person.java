
public interface Person {
	public String getName();
    public void setName(String nm);
}
